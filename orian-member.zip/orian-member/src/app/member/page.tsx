"use client";
import { motion, AnimatePresence } from "framer-motion";
import { QRCodeSVG } from "qrcode.react";
import Image from "next/image";
import Link from "next/link";
import { Suspense, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Logo, LangToggle, GlassCard, Spinner, DaifukuStamp } from "@/components/ui";
import { SWRegister } from "@/components/Celebration";
import { useLang } from "@/i18n/LangProvider";
import { api, IG_BRAND } from "@/lib/client";
import {
  TOTAL_STAMPS, nextRewardGap, unlockedRewards,
  type Member, type StampEvent, type Redemption, type SurpriseReward, type RewardRule,
} from "@/lib/types";

interface Payload {
  member: Member; stamps: StampEvent[]; redemptions: Redemption[];
  surprises: SurpriseReward[]; reward_rules: RewardRule[]; birthday_today: boolean;
}

function MemberInner() {
  const { t, lang } = useLang();
  const id = useSearchParams().get("id");
  const [data, setData] = useState<Payload | null>(null);
  const [following, setFollowing] = useState(false);
  const [tab, setTab] = useState<"card" | "stamps" | "rewards">("card");

  useEffect(() => {
    if (!id) return;
    const load = () => api<Payload>(`/api/members?id=${id}`).then(setData).catch(() => {});
    load();
    const poll = setInterval(load, 5000); // live update when staff adds a stamp
    return () => clearInterval(poll);
  }, [id]);

  if (!id) return <Center>{t.err_not_found}</Center>;
  if (!data) return <main className="min-h-screen bg-cocoa-atmos pt-20"><Spinner /></main>;

  const { member, stamps, redemptions, surprises, reward_rules, birthday_today } = data;
  const gap = nextRewardGap(member.stamps, reward_rules);
  const unlocked = unlockedRewards(member.stamps, reward_rules);
  const claimedCodes = new Set(redemptions.filter((r) => r.cycle === member.cycle).map((r) => r.reward_code));
  const memberUrl = typeof window !== "undefined" ? window.location.href : "";
  const label = (r: RewardRule) => (lang === "zh" ? r.label_zh : r.label_en);
  const bdayClaimed = member.birthday_gift_claimed_year === new Date().getFullYear();

  return (
    <main className="min-h-screen bg-cocoa-atmos pb-16">
      <SWRegister />
      <header className="flex items-center justify-between px-5 py-4 max-w-md mx-auto">
        <Link href="/"><Logo size={38} /></Link>
        <LangToggle />
      </header>

      <div className="max-w-md mx-auto px-5 space-y-5">
        {/* ─── Membership card ─── */}
        <GlassCard className="overflow-hidden">
          <div className="bg-gradient-to-br from-cocoa to-cocoa-deep p-6 relative">
            <div className="absolute top-0 right-0 w-40 h-40 bg-rose/10 rounded-full blur-3xl" />
            <div className="flex items-center gap-4 relative">
              <div className="w-16 h-16 rounded-2xl overflow-hidden ring-2 ring-rose/40 bg-cocoa-dark flex items-center justify-center shrink-0">
                {member.avatar_url
                  ? <img src={member.avatar_url} alt="" className="w-full h-full object-cover" />
                  : <span className="serif text-3xl text-rose">{(member.ig_handle ?? "O")[0]?.toUpperCase()}</span>}
              </div>
              <div className="min-w-0">
                <p className="text-gold text-[10px] tracking-[0.3em]">{t.mc_member} · O&rsquo;RIAN</p>
                <p className="serif text-2xl text-cream truncate">{member.ig_handle ? `@${member.ig_handle}` : t.mc_member}</p>
                <p className="text-cream/50 text-xs mt-0.5">{t.mc_phone}: ••••{member.phone.slice(-4)}</p>
              </div>
            </div>
            <div className="flex items-center justify-between mt-5 relative">
              <div>
                <p className="text-cream/50 text-xs">{t.mc_stamps}</p>
                <p className="serif text-4xl text-gold-shimmer">{member.stamps}<span className="text-cream/40 text-xl">/{TOTAL_STAMPS}</span></p>
              </div>
              <div className="bg-cream rounded-xl p-2">
                <QRCodeSVG value={memberUrl} size={72} fgColor="#513c3b" bgColor="#f6efe9" />
              </div>
            </div>
            <p className="text-cream/40 text-[10px] text-center mt-2">{t.mc_qr_hint}</p>
          </div>
          <p className="text-center text-cream/40 text-[11px] py-2 px-4">{t.mc_view_only}</p>
        </GlassCard>

        {/* ─── Tabs ─── */}
        <div className="glass rounded-full p-1 flex text-sm">
          {([["card", t.feat_collect], ["rewards", t.mc_redeemable], ["stamps", t.mc_history_stamp]] as const).map(([k, lbl]) => (
            <button key={k} onClick={() => setTab(k)}
              className={`flex-1 py-2.5 rounded-full transition ${tab === k ? "bg-rose text-cocoa-dark font-medium" : "text-cream/60"}`}>{lbl}</button>
          ))}
        </div>

        <AnimatePresence mode="wait">
          {tab === "card" && (
            <motion.div key="card" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-5">
              {/* Stamp grid */}
              <GlassCard className="p-5">
                {gap
                  ? <p className="text-center text-cream/70 text-sm mb-4">{t.mc_to_next}: <span className="text-gold font-semibold">{gap.gap} {t.mc_grids}</span> → {label(gap.rule)}</p>
                  : <p className="text-center text-gold text-sm mb-4">✦ {t.mc_redeemable} ✦</p>}
                <div className="grid grid-cols-4 gap-3">
                  {Array.from({ length: TOTAL_STAMPS }).map((_, i) => (
                    <DaifukuStamp key={i} index={i} unlocked={i < member.stamps} />
                  ))}
                </div>
              </GlassCard>

              {/* Birthday gift */}
              {member.birthday && (
                <GlassCard className={`p-5 ${birthday_today && !bdayClaimed ? "border border-gold/40 shadow-gold" : ""}`}>
                  <p className="text-gold text-xs tracking-[0.2em] mb-1">🎂 {t.mc_birthday_gift}</p>
                  {birthday_today
                    ? (bdayClaimed
                      ? <p className="text-cream/50 text-sm">{t.mc_birthday_claimed}</p>
                      : <p className="text-cream text-sm">{t.mc_birthday_ready}</p>)
                    : <p className="text-cream/60 text-sm">{t.feat_birthday_d} · {member.birthday}</p>}
                </GlassCard>
              )}

              {/* Surprise rewards */}
              {surprises.length > 0 && (
                <GlassCard className="p-5">
                  <p className="text-gold text-xs tracking-[0.2em] mb-2">✨ {t.mc_surprise}</p>
                  {surprises.map((s) => (
                    <div key={s.id} className={`flex items-center justify-between py-1.5 ${s.claimed ? "opacity-40" : ""}`}>
                      <span className="text-cream text-sm">{s.content}</span>
                      {s.claimed && <span className="text-xs text-cream/50">{t.mc_claimed}</span>}
                    </div>
                  ))}
                </GlassCard>
              )}

              {/* IG follow */}
              <a href={IG_BRAND} target="_blank" rel="noreferrer" onClick={() => setFollowing(true)}
                className={`block text-center py-4 rounded-2xl font-medium tap transition ${following ? "glass text-rose-light" : "bg-gradient-to-r from-rose to-rose-deep text-cocoa-dark shadow-gold hover:scale-[1.02]"}`}>
                {following ? t.mc_following : `♡ ${t.mc_follow} @orian.dessert`}
              </a>
            </motion.div>
          )}

          {tab === "rewards" && (
            <motion.div key="rw" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-3">
              {reward_rules.map((r) => {
                const isUnlocked = member.stamps >= r.threshold;
                const isClaimed = claimedCodes.has(r.code);
                return (
                  <motion.div key={r.code} layout
                    className={`rounded-2xl p-5 flex items-center justify-between transition ${
                      isClaimed ? "glass opacity-50" : isUnlocked ? "bg-gradient-to-r from-gold/25 to-rose/20 border border-gold/40 shadow-gold" : "glass border-dashed border-rose/20"}`}>
                    <div>
                      <p className={`serif text-xl ${isUnlocked ? "text-cream" : "text-cream/50"}`}>{label(r)}</p>
                      <p className="text-xs text-cream/50">{t.r_unlock_at.replace("{n}", String(r.threshold))}</p>
                    </div>
                    <span className={`text-xs px-3 py-1.5 rounded-full ${isClaimed ? "bg-cream/10 text-cream/50" : isUnlocked ? "bg-gold text-cocoa-dark font-medium" : "bg-cream/5 text-cream/40"}`}>
                      {isClaimed ? t.mc_claimed : isUnlocked ? t.mc_unlocked : t.mc_locked}
                    </span>
                  </motion.div>
                );
              })}
            </motion.div>
          )}

          {tab === "stamps" && (
            <motion.div key="st" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-4">
              <GlassCard className="p-5">
                <p className="text-cream/70 text-sm mb-3">{t.mc_history_stamp}</p>
                {stamps.length === 0 && <p className="text-cream/40 text-sm">—</p>}
                {stamps.map((s) => (
                  <Row key={s.id} left={`${s.delta > 0 ? "+" : ""}${s.delta} 🍓`}
                    mid={new Date(s.created_at).toLocaleDateString()}
                    right={s.expired ? "expired" : `#${s.cycle}`} dim={s.expired} />
                ))}
              </GlassCard>
              <GlassCard className="p-5">
                <p className="text-cream/70 text-sm mb-3">{t.mc_history_reward}</p>
                {redemptions.length === 0 && <p className="text-cream/40 text-sm">—</p>}
                {redemptions.map((r) => (
                  <Row key={r.id} left={lang === "zh" ? (reward_rules.find(x => x.code === r.reward_code)?.label_zh ?? r.reward_label) : r.reward_label}
                    mid={new Date(r.created_at).toLocaleDateString()} right={`#${r.cycle}`} />
                ))}
              </GlassCard>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </main>
  );
}

function Row({ left, mid, right, dim }: { left: string; mid: string; right: string; dim?: boolean }) {
  return (
    <div className={`flex items-center justify-between py-2 border-b border-cream/5 last:border-0 ${dim ? "opacity-40" : ""}`}>
      <span className="text-cream text-sm">{left}</span>
      <span className="text-cream/40 text-xs">{mid}</span>
      <span className="text-gold/60 text-xs">{right}</span>
    </div>
  );
}
function Center({ children }: { children: React.ReactNode }) {
  return <main className="min-h-screen bg-cocoa-atmos flex items-center justify-center text-cream/60">{children}</main>;
}
export default function MemberPage() {
  return <Suspense><MemberInner /></Suspense>;
}
