import { supabaseAdmin } from "@/lib/supabase";
import { getSession, requireOwner } from "@/lib/auth";
import { jsonError, logAudit } from "@/lib/api";

// GET /api/settings → public (market location shown on landing & member card)
export async function GET() {
  const db = supabaseAdmin();
  const { data } = await db.from("settings").select("*").eq("id", 1).single();
  return Response.json(data ?? {});
}

// PATCH /api/settings → Owner only (reward rules + market location)
export async function PATCH(req: Request) {
  const session = await getSession();
  if (!requireOwner(session)) return jsonError("err_no_permission", 403);

  const body = await req.json().catch(() => ({}));
  const patch: Record<string, unknown> = { updated_at: new Date().toISOString() };
  if (body.reward_rules) patch.reward_rules = body.reward_rules;
  if (body.market_location !== undefined) patch.market_location = body.market_location;

  const db = supabaseAdmin();
  const { error } = await db.from("settings").update(patch).eq("id", 1);
  if (error) return jsonError("err_generic", 500);
  await logAudit({ staff_username: session.username, action: "update_settings" });
  return Response.json({ ok: true });
}
