import { supabaseAdmin } from "@/lib/supabase";
import { createSession, clearSession } from "@/lib/auth";
import { jsonError, logAudit } from "@/lib/api";

// POST /api/auth  { username, password }  → sets session cookie
export async function POST(req: Request) {
  const { username, password } = await req.json().catch(() => ({}));
  if (!username || !password) return jsonError("err_login_failed", 401);

  if (password !== (process.env.ADMIN_SHARED_PASSWORD ?? "0809"))
    return jsonError("err_login_failed", 401);

  const db = supabaseAdmin();
  const { data: staff } = await db.from("staff").select("*").eq("username", username).single();
  if (!staff) return jsonError("err_login_failed", 401);

  await createSession({ username: staff.username, role: staff.role });
  await logAudit({ staff_username: staff.username, action: "login" });
  return Response.json({ ok: true, role: staff.role, username: staff.username });
}

// DELETE /api/auth → logout
export async function DELETE() {
  clearSession();
  return Response.json({ ok: true });
}
