import { supabaseAdmin } from "@/lib/supabase";
import { getSession, requireOwner } from "@/lib/auth";
import { jsonError, logAudit } from "@/lib/api";

const startOfToday = () => { const d = new Date(); d.setHours(0,0,0,0); return d.toISOString(); };
const startOfMonth = () => { const d = new Date(); d.setDate(1); d.setHours(0,0,0,0); return d.toISOString(); };

// GET /api/admin?view=session | dashboard | staff | audit
export async function GET(req: Request) {
  const session = await getSession();
  if (!session) return jsonError("err_no_permission", 401);
  const view = new URL(req.url).searchParams.get("view");
  const db = supabaseAdmin();

  if (view === "session") return Response.json(session);

  if (view === "dashboard") {
    const today = startOfToday();
    const month = startOfMonth();
    const [
      todayNew, todayStamps, todayRedeem, total, monthNew, monthRedeem, recent, redemptionsAll, stampsAll,
    ] = await Promise.all([
      db.from("members").select("id", { count: "exact", head: true }).gte("created_at", today),
      db.from("stamp_events").select("id", { count: "exact", head: true }).gte("created_at", today).gt("delta", 0),
      db.from("redemptions").select("id", { count: "exact", head: true }).gte("created_at", today),
      db.from("members").select("id", { count: "exact", head: true }),
      db.from("members").select("id", { count: "exact", head: true }).gte("created_at", month),
      db.from("redemptions").select("id", { count: "exact", head: true }).gte("created_at", month),
      db.from("members").select("*").order("last_stamp_at", { ascending: false, nullsFirst: false }).limit(8),
      db.from("redemptions").select("reward_label"),
      db.from("stamp_events").select("member_id,delta").gt("delta", 0),
    ]);

    // Most active members (by total stamps earned)
    const counts: Record<string, number> = {};
    (stampsAll.data ?? []).forEach((s) => { counts[s.member_id] = (counts[s.member_id] ?? 0) + 1; });
    const topIds = Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 5);
    const { data: activeMembers } = topIds.length
      ? await db.from("members").select("*").in("id", topIds.map(([id]) => id))
      : { data: [] as any[] };
    const active = topIds.map(([id, n]) => ({ member: (activeMembers ?? []).find((m) => m.id === id), count: n }))
      .filter((x) => x.member);

    // Popular rewards
    const rewardCounts: Record<string, number> = {};
    (redemptionsAll.data ?? []).forEach((r) => { rewardCounts[r.reward_label] = (rewardCounts[r.reward_label] ?? 0) + 1; });
    const popular = Object.entries(rewardCounts).sort((a, b) => b[1] - a[1]).map(([label, count]) => ({ label, count }));

    return Response.json({
      todayNew: todayNew.count ?? 0,
      todayStamps: todayStamps.count ?? 0,
      todayRedeem: todayRedeem.count ?? 0,
      total: total.count ?? 0,
      monthNew: monthNew.count ?? 0,
      monthRedeem: monthRedeem.count ?? 0,
      recent: recent.data ?? [],
      active, popular,
    });
  }

  if (view === "staff") {
    const { data } = await db.from("staff").select("*").order("created_at");
    return Response.json(data ?? []);
  }

  if (view === "audit") {
    const { data } = await db.from("audit_log").select("*").order("created_at", { ascending: false }).limit(200);
    return Response.json(data ?? []);
  }

  return jsonError("err_generic");
}

// POST /api/admin  { username, role } → Owner adds staff
export async function POST(req: Request) {
  const session = await getSession();
  if (!requireOwner(session)) return jsonError("err_no_permission", 403);
  const { username, role } = await req.json().catch(() => ({}));
  if (!username || !["owner", "staff"].includes(role)) return jsonError("err_generic");
  const db = supabaseAdmin();
  const { error } = await db.from("staff").insert({ username, role });
  if (error) return jsonError("err_generic", 409);
  await logAudit({ staff_username: session.username, action: "add_staff", notes: `${username} (${role})` });
  return Response.json({ ok: true });
}

// DELETE /api/admin  { id } → Owner removes staff
export async function DELETE(req: Request) {
  const session = await getSession();
  if (!requireOwner(session)) return jsonError("err_no_permission", 403);
  const { id } = await req.json().catch(() => ({}));
  const db = supabaseAdmin();
  await db.from("staff").delete().eq("id", id);
  await logAudit({ staff_username: session.username, action: "delete_staff" });
  return Response.json({ ok: true });
}
