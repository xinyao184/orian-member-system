import { supabaseAdmin } from "@/lib/supabase";
import { getSession } from "@/lib/auth";
import { jsonError, logAudit, getRewardRules } from "@/lib/api";
import { TOTAL_STAMPS, STAMP_EXPIRY_DAYS } from "@/lib/types";

// POST /api/stamps  { member_id, delta: 1 | -1, notes? }
// Staff & Owner can +1. Only Owner can -1 (staff correction restricted).
export async function POST(req: Request) {
  const session = await getSession();
  if (!session) return jsonError("err_no_permission", 401);

  const { member_id, delta = 1, notes = null } = await req.json().catch(() => ({}));
  if (!member_id) return jsonError("err_generic");
  if (delta === -1 && session.role !== "owner") return jsonError("err_no_permission", 403);

  const db = supabaseAdmin();
  const { data: member } = await db.from("members").select("*").eq("id", member_id).single();
  if (!member) return jsonError("err_not_found", 404);

  // Expiry check: if last stamp > 365 days ago, archive current cycle first.
  let stamps = member.stamps;
  let cycle = member.cycle;
  if (member.last_stamp_at) {
    const ageDays = (Date.now() - new Date(member.last_stamp_at).getTime()) / 86_400_000;
    if (ageDays > STAMP_EXPIRY_DAYS) {
      await db.from("stamp_events").update({ expired: true }).eq("member_id", member_id).eq("cycle", cycle);
      stamps = 0;
      cycle += 1;
    }
  }

  const next = Math.max(0, Math.min(TOTAL_STAMPS, stamps + delta));
  if (next === stamps) return jsonError("err_generic"); // nothing changed (e.g. -1 at 0)

  await db.from("stamp_events").insert({
    member_id, cycle, delta, staff_username: session.username, notes,
  });
  await db.from("members").update({
    stamps: next, cycle, last_stamp_at: new Date().toISOString(),
  }).eq("id", member_id);

  await logAudit({
    staff_username: session.username, member_phone: member.phone, member_ig: member.ig_handle,
    action: delta > 0 ? "add_stamp" : "remove_stamp", notes,
  });

  const rules = await getRewardRules();
  const justUnlocked = rules.find((r) => r.threshold === next) ?? null;
  return Response.json({ ok: true, stamps: next, cycle, justUnlocked });
}
