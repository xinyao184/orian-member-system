import { supabaseAdmin } from "@/lib/supabase";
import { getSession } from "@/lib/auth";
import { jsonError, logAudit, normalizePhone, getRewardRules, isBirthdayToday } from "@/lib/api";

// Assemble a full member payload (member + stamps + redemptions + surprises).
async function fullMember(id: string) {
  const db = supabaseAdmin();
  const { data: member } = await db.from("members").select("*").eq("id", id).single();
  if (!member) return null;
  const [{ data: stamps }, { data: redemptions }, { data: surprises }, rules] = await Promise.all([
    db.from("stamp_events").select("*").eq("member_id", id).order("created_at", { ascending: false }),
    db.from("redemptions").select("*").eq("member_id", id).order("created_at", { ascending: false }),
    db.from("surprise_rewards").select("*").eq("member_id", id).order("created_at", { ascending: false }),
    getRewardRules(),
  ]);
  return {
    member,
    stamps: stamps ?? [],
    redemptions: redemptions ?? [],
    surprises: surprises ?? [],
    reward_rules: rules,
    birthday_today: isBirthdayToday(member.birthday),
  };
}

// GET /api/members?id=... | ?phone=... | ?q=... (staff search) | (all, staff)
export async function GET(req: Request) {
  const url = new URL(req.url);
  const id = url.searchParams.get("id");
  const phone = url.searchParams.get("phone");
  const q = url.searchParams.get("q");
  const db = supabaseAdmin();

  // Public: fetch own card by UUID (no phone exposed in URL)
  if (id) {
    const data = await fullMember(id);
    return data ? Response.json(data) : jsonError("err_not_found", 404);
  }

  // Public: lookup own card by phone (member self-service "find my card")
  if (phone) {
    const norm = normalizePhone(phone);
    if (!norm) return jsonError("err_phone_invalid");
    const { data: m } = await db.from("members").select("id").eq("phone", norm).single();
    return m ? Response.json({ id: m.id }) : jsonError("err_not_found", 404);
  }

  // Staff-only beyond this point
  const session = await getSession();
  if (!session) return jsonError("err_no_permission", 401);

  // Market Mode search — phone is primary key, then IG (per owner decision)
  if (q !== null) {
    const term = q.trim();
    if (!term) {
      const { data } = await db.from("members").select("*")
        .order("last_stamp_at", { ascending: false, nullsFirst: false }).limit(8);
      return Response.json(data ?? []);
    }
    const { data } = await db.from("members").select("*")
      .or(`phone.ilike.%${term}%,ig_handle.ilike.%${term}%`)
      .limit(20);
    // sort phone matches first
    const sorted = (data ?? []).sort((a, b) => {
      const ap = a.phone.includes(term) ? 0 : 1;
      const bp = b.phone.includes(term) ? 0 : 1;
      return ap - bp;
    });
    return Response.json(sorted);
  }

  // Full list (Customer List page)
  const { data } = await db.from("members").select("*").order("created_at", { ascending: false });
  return Response.json(data ?? []);
}

// POST /api/members → public self-registration
export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const norm = normalizePhone(body.phone ?? "");
  if (!body.phone) return jsonError("err_phone_required");
  if (!norm) return jsonError("err_phone_invalid");

  const db = supabaseAdmin();
  const { data: existing } = await db.from("members").select("id").eq("phone", norm).single();
  if (existing) return jsonError("err_phone_exists", 409);

  const ig = (body.ig_handle ?? "").replace(/^@/, "").trim() || null;
  const { data: created, error } = await db.from("members").insert({
    phone: norm,
    ig_handle: ig,
    avatar_url: body.avatar_url || null,
    birthday: body.birthday || null,
  }).select("id").single();
  if (error || !created) return jsonError("err_generic", 500);

  // Self-registration is logged as the member's own action
  await logAudit({ staff_username: "self-register", member_phone: norm, member_ig: ig, action: "register" });
  return Response.json({ id: created.id });
}

// PATCH /api/members → staff edits member profile
export async function PATCH(req: Request) {
  const session = await getSession();
  if (!session) return jsonError("err_no_permission", 401);
  const body = await req.json().catch(() => ({}));
  if (!body.id) return jsonError("err_generic");
  const db = supabaseAdmin();

  const patch: Record<string, unknown> = {};
  if (body.phone !== undefined) {
    const norm = normalizePhone(body.phone);
    if (!norm) return jsonError("err_phone_invalid");
    patch.phone = norm;
  }
  if (body.ig_handle !== undefined) patch.ig_handle = (body.ig_handle || "").replace(/^@/, "").trim() || null;
  if (body.birthday !== undefined) patch.birthday = body.birthday || null;
  if (body.avatar_url !== undefined) patch.avatar_url = body.avatar_url || null;

  const { data: m, error } = await db.from("members").update(patch).eq("id", body.id).select("*").single();
  if (error || !m) return jsonError("err_generic", 500);
  await logAudit({ staff_username: session.username, member_phone: m.phone, member_ig: m.ig_handle, action: "edit_profile", notes: body.notes });
  return Response.json({ ok: true, member: m });
}
