import { supabaseAdmin } from "@/lib/supabase";
import { getSession, requireOwner } from "@/lib/auth";
import { jsonError, logAudit } from "@/lib/api";
import * as XLSX from "xlsx";

// GET /api/export?format=csv|xlsx → Owner only
export async function GET(req: Request) {
  const session = await getSession();
  if (!requireOwner(session)) return jsonError("err_no_permission", 403);
  const format = new URL(req.url).searchParams.get("format") ?? "csv";

  const db = supabaseAdmin();
  const { data: members } = await db.from("members").select("*").order("created_at");
  const rows = (members ?? []).map((m) => ({
    "Member ID": m.id,
    Phone: m.phone,
    Instagram: m.ig_handle ?? "",
    Birthday: m.birthday ?? "",
    Stamps: m.stamps,
    Cycle: m.cycle,
    "Last Stamp": m.last_stamp_at ?? "",
    Joined: m.created_at,
  }));

  await logAudit({ staff_username: session.username, action: "export", notes: format });

  if (format === "xlsx") {
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Members");
    const buf = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });
    return new Response(buf, {
      headers: {
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": `attachment; filename="orian-members-${Date.now()}.xlsx"`,
      },
    });
  }

  // CSV
  const headers = Object.keys(rows[0] ?? { "Member ID": "" });
  const csv = [
    headers.join(","),
    ...rows.map((r) => headers.map((h) => `"${String((r as any)[h]).replace(/"/g, '""')}"`).join(",")),
  ].join("\n");
  return new Response("\uFEFF" + csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="orian-members-${Date.now()}.csv"`,
    },
  });
}
