import { supabaseAdmin } from "@/lib/supabase";
import { getSession } from "@/lib/auth";
import { jsonError, logAudit, getRewardRules } from "@/lib/api";

// POST /api/redemptions  { member_id, reward_code, notes? }
// Rule: each milestone reward claimable once per cycle.
// The 12-stamp reward (resets:true) clears stamps & starts a new cycle;
// all history is preserved (events/redemptions keep their cycle number).
export async function POST(req: Request) {
  const session = await getSession();
  if (!session) return jsonError("err_no_permission", 401);

  const { member_id, reward_code, notes = null } = await req.json().catch(() => ({}));
  if (!member_id || !reward_code) return jsonError("err_generic");

  const db = supabaseAdmin();
  const { data: member } = await db.from("members").select("*").eq("id", member_id).single();
  if (!member) return jsonError("err_not_found", 404);

  const rules = await getRewardRules();
  const rule = rules.find((r) => r.code === reward_code);
  if (!rule) return jsonError("err_generic");
  if (member.stamps < rule.threshold) return jsonError("err_not_enough");

  // Once-per-cycle enforcement (also guarded by unique index in DB)
  const { data: already } = await db.from("redemptions").select("id")
    .eq("member_id", member_id).eq("cycle", member.cycle).eq("reward_code", reward_code).maybeSingle();
  if (already) return jsonError("err_already_claimed", 409);

  const { error: insErr } = await db.from("redemptions").insert({
    member_id, cycle: member.cycle, reward_code, reward_label: rule.label_en,
    staff_username: session.username, notes,
  });
  if (insErr) return jsonError("err_already_claimed", 409);

  // 12-stamp reward resets the cycle.
  if (rule.resets) {
    await db.from("stamp_events").update({ expired: true }).eq("member_id", member_id).eq("cycle", member.cycle);
    await db.from("members").update({ stamps: 0, cycle: member.cycle + 1 }).eq("id", member_id);
  }

  await logAudit({
    staff_username: session.username, member_phone: member.phone, member_ig: member.ig_handle,
    action: "redeem", notes: `${rule.code}${notes ? " · " + notes : ""}`,
  });
  return Response.json({ ok: true, reset: rule.resets });
}
