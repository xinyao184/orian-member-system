"use client";
import { motion } from "framer-motion";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { Suspense, useState } from "react";
import { Logo, LangToggle } from "@/components/ui";
import { useLang } from "@/i18n/LangProvider";
import { api } from "@/lib/client";

function RegisterInner() {
  const { t } = useLang();
  const router = useRouter();
  const params = useSearchParams();
  const [mode, setMode] = useState<"register" | "lookup">(params.get("lookup") ? "lookup" : "register");
  const [phone, setPhone] = useState("");
  const [ig, setIg] = useState("");
  const [birthday, setBirthday] = useState("");
  const [avatar, setAvatar] = useState<string | null>(null);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  async function onAvatar(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setAvatar(reader.result as string);
    reader.readAsDataURL(file); // stored inline as data URL (simple, no bucket dependency)
  }

  async function submit() {
    setErr(""); setBusy(true);
    try {
      if (mode === "register") {
        const { id } = await api<{ id: string }>("/api/members", {
          method: "POST",
          body: JSON.stringify({ phone, ig_handle: ig, birthday, avatar_url: avatar }),
        });
        router.push(`/member?id=${id}`);
      } else {
        const { id } = await api<{ id: string }>(`/api/members?phone=${encodeURIComponent(phone)}`);
        router.push(`/member?id=${id}`);
      }
    } catch (e: any) {
      setErr((t as any)[e.message] ?? t.err_generic);
    } finally { setBusy(false); }
  }

  return (
    <main className="min-h-screen bg-cocoa-atmos px-6 py-6">
      <header className="flex items-center justify-between max-w-md mx-auto mb-8">
        <Link href="/"><Logo size={40} /></Link>
        <LangToggle />
      </header>

      <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }}
        className="glass rounded-3xl p-7 max-w-md mx-auto shadow-card">
        <h1 className="serif text-4xl text-rose-light text-center">{mode === "register" ? t.reg_title : t.reg_lookup}</h1>
        <p className="text-cream/60 text-sm text-center mt-1 mb-6">{mode === "register" ? t.reg_sub : t.reg_lookup_ph}</p>

        <div className="space-y-4">
          <Field label={t.reg_phone}>
            <input value={phone} onChange={(e) => setPhone(e.target.value)} inputMode="tel"
              placeholder={mode === "register" ? t.reg_phone_ph : t.reg_lookup_ph} className="inp" />
          </Field>

          {mode === "register" && (
            <>
              <Field label={t.reg_ig}>
                <input value={ig} onChange={(e) => setIg(e.target.value)} placeholder={t.reg_ig_ph} className="inp" />
              </Field>
              <Field label={t.reg_birthday}>
                <input type="date" value={birthday} onChange={(e) => setBirthday(e.target.value)} className="inp" />
              </Field>
              <Field label={t.reg_avatar}>
                <div className="flex items-center gap-3">
                  {avatar && <img src={avatar} alt="" className="w-12 h-12 rounded-full object-cover ring-2 ring-rose/40" />}
                  <input type="file" accept="image/*" onChange={onAvatar}
                    className="text-cream/60 text-sm file:mr-3 file:rounded-full file:border-0 file:bg-rose/20 file:px-4 file:py-2 file:text-rose-light" />
                </div>
              </Field>
            </>
          )}

          {err && <p className="text-strawberry text-sm text-center">{err}</p>}

          <button onClick={submit} disabled={busy}
            className="w-full py-4 rounded-full bg-gradient-to-r from-rose to-rose-deep text-cocoa-dark font-semibold shadow-gold tap disabled:opacity-50 transition hover:scale-[1.02]">
            {busy ? t.loading : mode === "register" ? t.reg_submit : t.reg_lookup}
          </button>

          <button onClick={() => { setMode(mode === "register" ? "lookup" : "register"); setErr(""); }}
            className="w-full text-center text-cream/50 text-sm hover:text-cream transition">
            {mode === "register" ? t.reg_have : t.nav_join}
          </button>
        </div>
      </motion.div>
      <style jsx>{`
        .inp { width: 100%; padding: 0.85rem 1rem; border-radius: 1rem; background: rgba(246,239,233,0.07);
          border: 1px solid rgba(246,239,233,0.15); color: #f6efe9; outline: none; transition: 0.2s; }
        .inp:focus { border-color: rgba(198,162,162,0.6); box-shadow: 0 0 0 3px rgba(198,162,162,0.15); }
      `}</style>
    </main>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-cream/60 text-xs tracking-wide mb-1.5 block">{label}</span>
      {children}
    </label>
  );
}

export default function RegisterPage() {
  return <Suspense><RegisterInner /></Suspense>;
}
