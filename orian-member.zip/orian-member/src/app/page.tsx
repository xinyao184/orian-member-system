"use client";
import { motion } from "framer-motion";
import Image from "next/image";
import Link from "next/link";
import { useEffect, useState } from "react";
import { Logo, LangToggle } from "@/components/ui";
import { SWRegister } from "@/components/Celebration";
import { useLang } from "@/i18n/LangProvider";
import { api } from "@/lib/client";
import type { MarketLocation } from "@/lib/types";

export default function Landing() {
  const { t } = useLang();
  const [market, setMarket] = useState<MarketLocation | null>(null);

  useEffect(() => {
    api("/api/settings").then((s) => setMarket(s.market_location)).catch(() => {});
  }, []);

  const fade = { initial: { opacity: 0, y: 20 }, animate: { opacity: 1, y: 0 } };

  return (
    <main className="min-h-screen bg-cocoa-atmos overflow-hidden">
      <SWRegister />
      <header className="flex items-center justify-between px-6 py-5 max-w-5xl mx-auto">
        <Logo size={44} />
        <div className="flex items-center gap-3">
          <LangToggle />
          <Link href="/admin/login" className="text-xs text-cream/50 hover:text-cream transition">{t.nav_admin}</Link>
        </div>
      </header>

      <section className="px-6 max-w-3xl mx-auto text-center pt-10 pb-16 relative">
        {/* Floating daifuku hero */}
        <motion.div
          animate={{ y: [0, -12, 0] }} transition={{ repeat: Infinity, duration: 5, ease: "easeInOut" }}
          className="mx-auto w-40 h-40 mb-6 relative"
        >
          <Image src="/brand/daifuku-crop.png" alt="Strawberry Daifuku" fill
            className="object-contain drop-shadow-[0_18px_40px_rgba(226,59,46,0.4)]" priority />
        </motion.div>

        <motion.p {...fade} transition={{ delay: 0.1 }} className="text-gold tracking-[0.35em] text-xs mb-3">{t.since}</motion.p>
        <motion.h1 {...fade} transition={{ delay: 0.2 }} className="serif text-6xl md:text-7xl text-rose-light mb-4">{t.hero_title}</motion.h1>
        <motion.p {...fade} transition={{ delay: 0.3 }} className="text-cream/70 text-lg mb-10 max-w-md mx-auto">{t.hero_sub}</motion.p>

        <motion.div {...fade} transition={{ delay: 0.4 }} className="flex flex-col items-center gap-3">
          <Link href="/register" className="group relative px-10 py-4 rounded-full bg-gradient-to-r from-rose to-rose-deep text-cocoa-dark font-semibold shadow-gold tap transition hover:scale-[1.03]">
            {t.hero_cta}
          </Link>
          <Link href="/register?lookup=1" className="text-cream/60 text-sm hover:text-cream transition">{t.hero_login}</Link>
        </motion.div>
      </section>

      {/* Features */}
      <section className="px-6 max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-4 pb-16">
        {[
          { t: t.feat_collect, d: t.feat_collect_d },
          { t: t.feat_reward, d: t.feat_reward_d },
          { t: t.feat_birthday, d: t.feat_birthday_d },
        ].map((f, i) => (
          <motion.div key={i} {...fade} transition={{ delay: 0.5 + i * 0.1 }}
            className="glass rounded-3xl p-6 text-center">
            <p className="serif text-2xl text-rose-light mb-2">{f.t}</p>
            <p className="text-cream/60 text-sm">{f.d}</p>
          </motion.div>
        ))}
      </section>

      {/* Latest market */}
      {market && market.place && (
        <motion.section {...fade} transition={{ delay: 0.8 }} className="px-6 max-w-md mx-auto pb-20">
          <div className="glass rounded-3xl p-6 text-center border border-gold/20">
            <p className="text-gold text-xs tracking-[0.3em] mb-2">📍 {t.market_latest}</p>
            <p className="serif text-2xl text-cream mb-1">{market.place}</p>
            {market.date && <p className="text-cream/70 text-sm">{market.date} {market.time}</p>}
            {market.note && <p className="text-cream/50 text-xs mt-2">{market.note}</p>}
          </div>
        </motion.section>
      )}

      <footer className="text-center pb-10 text-cream/40 text-xs flex justify-center gap-6">
        <Link href="/privacy" className="hover:text-cream">{t.f_privacy}</Link>
        <Link href="/terms" className="hover:text-cream">{t.f_terms}</Link>
      </footer>
    </main>
  );
}
