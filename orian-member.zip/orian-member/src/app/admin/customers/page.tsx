"use client";
import Link from "next/link";
import { Search } from "lucide-react";
import { useEffect, useState } from "react";
import { AdminShell } from "@/components/AdminShell";
import { GlassCard, Spinner } from "@/components/ui";
import { useLang } from "@/i18n/LangProvider";
import { api } from "@/lib/client";
import { TOTAL_STAMPS, type Member } from "@/lib/types";

export default function CustomersPage() {
  return <AdminShell><Customers /></AdminShell>;
}

function Customers() {
  const { t } = useLang();
  const [members, setMembers] = useState<Member[] | null>(null);
  const [q, setQ] = useState("");
  useEffect(() => { api<Member[]>("/api/members").then(setMembers).catch(() => {}); }, []);
  if (!members) return <Spinner />;

  const filtered = members.filter((m) =>
    !q || m.phone.includes(q) || (m.ig_handle ?? "").toLowerCase().includes(q.toLowerCase()));

  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <h1 className="serif text-3xl text-rose-light">{t.a_customers}</h1>
        <span className="text-cream/50 text-sm">{members.length}</span>
      </div>
      <div className="relative mb-4">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-cream/40" size={20} />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t.m_search}
          className="w-full pl-11 pr-4 py-3 rounded-2xl bg-cream/10 border border-cream/15 text-cream placeholder-cream/30 outline-none focus:border-rose/60" />
      </div>
      <div className="space-y-2">
        {filtered.map((m) => (
          <Link key={m.id} href={`/admin/customers/detail?id=${m.id}`}>
            <GlassCard className="p-4 flex items-center gap-3 hover:border-rose/40 transition">
              <div className="w-11 h-11 rounded-xl overflow-hidden ring-1 ring-rose/30 bg-cocoa-dark flex items-center justify-center shrink-0">
                {m.avatar_url ? <img src={m.avatar_url} alt="" className="w-full h-full object-cover" /> : <span className="serif text-lg text-rose">{(m.ig_handle ?? "O")[0]?.toUpperCase()}</span>}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-cream truncate">{m.ig_handle ? `@${m.ig_handle}` : m.phone}</p>
                <p className="text-cream/40 text-xs">{m.phone}</p>
              </div>
              <span className="serif text-xl text-gold">{m.stamps}<span className="text-cream/30 text-sm">/{TOTAL_STAMPS}</span></span>
            </GlassCard>
          </Link>
        ))}
      </div>
    </div>
  );
}
