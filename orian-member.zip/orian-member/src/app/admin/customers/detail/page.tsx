"use client";
import { Instagram, Plus, Minus, Gift, Sparkles } from "lucide-react";
import Link from "next/link";
import { Suspense, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { AdminShell } from "@/components/AdminShell";
import { GlassCard, Spinner } from "@/components/ui";
import { useLang } from "@/i18n/LangProvider";
import { api, igUrl } from "@/lib/client";
import {
  TOTAL_STAMPS, unlockedRewards,
  type Member, type StampEvent, type Redemption, type SurpriseReward, type RewardRule,
} from "@/lib/types";
import type { Session } from "@/lib/auth";

interface Payload {
  member: Member; stamps: StampEvent[]; redemptions: Redemption[];
  surprises: SurpriseReward[]; reward_rules: RewardRule[]; birthday_today: boolean;
}

export default function DetailPage() {
  return <AdminShell><Suspense><Detail /></Suspense></AdminShell>;
}

function Detail() {
  const { t, lang } = useLang();
  const id = useSearchParams().get("id");
  const [d, setD] = useState<Payload | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [surprise, setSurprise] = useState("");
  const [busy, setBusy] = useState(false);

  const load = () => id && api<Payload>(`/api/members?id=${id}`).then(setD).catch(() => {});
  useEffect(() => { load(); api<Session>("/api/admin?view=session").then(setSession).catch(() => {}); /* eslint-disable-next-line */ }, [id]);
  if (!d) return <Spinner />;
  const { member, stamps, redemptions, surprises, reward_rules } = d;
  const isOwner = session?.role === "owner";
  const claimed = new Set(redemptions.filter((r) => r.cycle === member.cycle).map((r) => r.reward_code));

  async function stamp(delta: number) {
    setBusy(true);
    try { await api("/api/stamps", { method: "POST", body: JSON.stringify({ member_id: id, delta }) }); load(); }
    catch (e: any) { alert((t as any)[e.message] ?? t.err_generic); } finally { setBusy(false); }
  }
  async function redeem(code: string) {
    setBusy(true);
    try { await api("/api/redemptions", { method: "POST", body: JSON.stringify({ member_id: id, reward_code: code }) }); load(); }
    catch (e: any) { alert((t as any)[e.message] ?? t.err_generic); } finally { setBusy(false); }
  }
  async function sendSurprise() {
    if (!surprise.trim()) return; setBusy(true);
    try { await api("/api/surprise", { method: "POST", body: JSON.stringify({ member_id: id, content: surprise }) }); setSurprise(""); load(); }
    catch (e: any) { alert((t as any)[e.message] ?? t.err_generic); } finally { setBusy(false); }
  }

  return (
    <div>
      <Link href="/admin/customers" className="text-cream/50 text-sm hover:text-cream">← {t.a_customers}</Link>
      <div className="flex items-center gap-4 my-5">
        <div className="w-16 h-16 rounded-2xl overflow-hidden ring-2 ring-rose/40 bg-cocoa-dark flex items-center justify-center">
          {member.avatar_url ? <img src={member.avatar_url} alt="" className="w-full h-full object-cover" /> : <span className="serif text-3xl text-rose">{(member.ig_handle ?? "O")[0]?.toUpperCase()}</span>}
        </div>
        <div>
          <h1 className="serif text-3xl text-rose-light">{member.ig_handle ? `@${member.ig_handle}` : t.mc_member}</h1>
          <p className="text-cream/50 text-sm">{member.phone} {member.birthday && `· 🎂 ${member.birthday}`}</p>
          {member.ig_handle && (
            <a href={igUrl(member.ig_handle)} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-gold text-sm mt-1 hover:underline">
              <Instagram size={14} /> {t.c_open_ig}
            </a>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Stamps control */}
        <GlassCard className="p-5">
          <div className="text-center mb-4">
            <p className="serif text-5xl text-gold-shimmer">{member.stamps}<span className="text-cream/30 text-2xl">/{TOTAL_STAMPS}</span></p>
            <p className="text-cream/50 text-xs">{t.mc_stamps} · cycle #{member.cycle}</p>
          </div>
          <div className="flex gap-2">
            <button onClick={() => stamp(1)} disabled={busy || member.stamps >= TOTAL_STAMPS}
              className="flex-1 py-4 rounded-2xl bg-gradient-to-r from-rose to-rose-deep text-cocoa-dark font-bold flex items-center justify-center gap-1 tap shadow-gold disabled:opacity-40 active:scale-95">
              <Plus size={20} /> {t.c_addstamp}
            </button>
            {isOwner && (
              <button onClick={() => stamp(-1)} disabled={busy || member.stamps <= 0}
                className="px-5 py-4 rounded-2xl glass text-cream/70 flex items-center justify-center tap disabled:opacity-40 active:scale-95">
                <Minus size={20} />
              </button>
            )}
          </div>
        </GlassCard>

        {/* Rewards */}
        <GlassCard className="p-5">
          <p className="text-cream/70 text-sm mb-3">{t.c_redeem_avail}</p>
          {reward_rules.map((r) => {
            const ok = member.stamps >= r.threshold && !claimed.has(r.code);
            const done = claimed.has(r.code);
            return (
              <button key={r.code} onClick={() => ok && redeem(r.code)} disabled={!ok || busy}
                className={`w-full flex items-center justify-between py-2.5 px-3 rounded-xl mb-2 transition ${ok ? "bg-gold/15 border border-gold/40 active:scale-95" : "glass opacity-60"}`}>
                <span className="text-cream text-sm flex items-center gap-2"><Gift size={16} />{lang === "zh" ? r.label_zh : r.label_en}</span>
                <span className="text-xs text-cream/50">{done ? t.mc_claimed : `${r.threshold}🍓`}</span>
              </button>
            );
          })}
        </GlassCard>

        {/* Surprise (Owner only) */}
        {isOwner && (
          <GlassCard className="p-5">
            <p className="text-cream/70 text-sm mb-3 flex items-center gap-2"><Sparkles size={16} /> {t.c_send_surprise}</p>
            <input value={surprise} onChange={(e) => setSurprise(e.target.value)} placeholder={t.c_surprise_ph}
              className="w-full px-3 py-2.5 rounded-xl bg-cream/10 border border-cream/15 text-cream placeholder-cream/30 outline-none focus:border-rose/60 mb-2 text-sm" />
            <button onClick={sendSurprise} disabled={busy}
              className="w-full py-2.5 rounded-xl bg-rose/20 text-rose-light text-sm tap active:scale-95">{t.c_send}</button>
          </GlassCard>
        )}

        {/* History */}
        <GlassCard className="p-5">
          <p className="text-cream/70 text-sm mb-3">{t.mc_history_stamp} / {t.mc_history_reward}</p>
          <div className="max-h-52 overflow-y-auto no-scrollbar">
            {[...stamps.map((s) => ({ k: s.id, l: `${s.delta > 0 ? "+" : ""}${s.delta} · ${s.staff_username}`, d: s.created_at, dim: s.expired })),
              ...redemptions.map((r) => ({ k: r.id, l: `🎁 ${r.reward_label} · ${r.staff_username}`, d: r.created_at, dim: false }))]
              .sort((a, b) => +new Date(b.d) - +new Date(a.d))
              .map((row) => (
                <div key={row.k} className={`flex justify-between py-1.5 text-xs border-b border-cream/5 last:border-0 ${row.dim ? "opacity-40" : ""}`}>
                  <span className="text-cream/80">{row.l}</span>
                  <span className="text-cream/40">{new Date(row.d).toLocaleDateString()}</span>
                </div>
              ))}
          </div>
        </GlassCard>
      </div>
    </div>
  );
}
