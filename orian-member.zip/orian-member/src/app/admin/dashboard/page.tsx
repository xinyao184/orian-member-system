"use client";
import { motion } from "framer-motion";
import Link from "next/link";
import { useEffect, useState } from "react";
import { AdminShell } from "@/components/AdminShell";
import { GlassCard, Spinner } from "@/components/ui";
import { useLang } from "@/i18n/LangProvider";
import { api } from "@/lib/client";
import type { Member } from "@/lib/types";

interface Stats {
  todayNew: number; todayStamps: number; todayRedeem: number; total: number;
  monthNew: number; monthRedeem: number;
  recent: Member[];
  active: { member: Member; count: number }[];
  popular: { label: string; count: number }[];
}

export default function DashboardPage() {
  return <AdminShell><Dashboard /></AdminShell>;
}

function Dashboard() {
  const { t } = useLang();
  const [s, setS] = useState<Stats | null>(null);
  useEffect(() => { api<Stats>("/api/admin?view=dashboard").then(setS).catch(() => {}); }, []);
  if (!s) return <Spinner />;

  const cards = [
    { label: t.a_today_new, value: s.todayNew, accent: "text-rose-light" },
    { label: t.a_today_stamps, value: s.todayStamps, accent: "text-gold" },
    { label: t.a_today_redeem, value: s.todayRedeem, accent: "text-cream" },
    { label: t.a_total_members, value: s.total, accent: "text-rose-light" },
    { label: t.a_month_new, value: s.monthNew, accent: "text-gold" },
    { label: t.a_month_redeem, value: s.monthRedeem, accent: "text-cream" },
  ];

  return (
    <div>
      <h1 className="serif text-3xl text-rose-light mb-6">{t.a_dashboard}</h1>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-6">
        {cards.map((c, i) => (
          <motion.div key={i} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
            <GlassCard className="p-5">
              <p className="text-cream/50 text-xs mb-2">{c.label}</p>
              <p className={`serif text-4xl ${c.accent}`}>{c.value}</p>
            </GlassCard>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <GlassCard className="p-5">
          <p className="text-cream/70 text-sm mb-3">{t.a_recent}</p>
          {s.recent.map((m) => (
            <Link key={m.id} href={`/admin/customers/detail?id=${m.id}`} className="flex items-center justify-between py-2 border-b border-cream/5 last:border-0 hover:opacity-70">
              <span className="text-cream text-sm truncate">{m.ig_handle ? `@${m.ig_handle}` : m.phone}</span>
              <span className="text-gold text-sm">{m.stamps}</span>
            </Link>
          ))}
          {s.recent.length === 0 && <p className="text-cream/40 text-sm">—</p>}
        </GlassCard>

        <GlassCard className="p-5">
          <p className="text-cream/70 text-sm mb-3">{t.a_active}</p>
          {s.active.map((a) => (
            <Link key={a.member.id} href={`/admin/customers/detail?id=${a.member.id}`} className="flex items-center justify-between py-2 border-b border-cream/5 last:border-0 hover:opacity-70">
              <span className="text-cream text-sm truncate">{a.member.ig_handle ? `@${a.member.ig_handle}` : a.member.phone}</span>
              <span className="text-gold text-sm">{a.count} 🍓</span>
            </Link>
          ))}
          {s.active.length === 0 && <p className="text-cream/40 text-sm">—</p>}
        </GlassCard>

        <GlassCard className="p-5">
          <p className="text-cream/70 text-sm mb-3">{t.a_popular}</p>
          {s.popular.map((p, i) => (
            <div key={i} className="flex items-center justify-between py-2 border-b border-cream/5 last:border-0">
              <span className="text-cream text-sm truncate">{p.label}</span>
              <span className="text-gold text-sm">{p.count}</span>
            </div>
          ))}
          {s.popular.length === 0 && <p className="text-cream/40 text-sm">—</p>}
        </GlassCard>
      </div>
    </div>
  );
}
