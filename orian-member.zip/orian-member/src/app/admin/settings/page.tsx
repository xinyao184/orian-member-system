"use client";
import { Download } from "lucide-react";
import { useEffect, useState } from "react";
import { AdminShell } from "@/components/AdminShell";
import { GlassCard, Spinner } from "@/components/ui";
import { useLang } from "@/i18n/LangProvider";
import { api } from "@/lib/client";
import type { RewardRule, MarketLocation } from "@/lib/types";

export default function SettingsPage() {
  return <AdminShell ownerOnly><SettingsView /></AdminShell>;
}

function SettingsView() {
  const { t, lang } = useLang();
  const [rules, setRules] = useState<RewardRule[] | null>(null);
  const [market, setMarket] = useState<MarketLocation>({ place: "", date: "", time: "", note: "" });
  const [saved, setSaved] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api("/api/settings").then((s) => {
      setRules(s.reward_rules ?? []);
      setMarket(s.market_location ?? { place: "", date: "", time: "", note: "" });
    }).catch(() => {});
  }, []);
  if (!rules) return <Spinner />;

  async function save() {
    setBusy(true);
    try {
      await api("/api/settings", { method: "PATCH", body: JSON.stringify({ reward_rules: rules, market_location: market }) });
      setSaved(true); setTimeout(() => setSaved(false), 2000);
    } catch (e: any) { alert((t as any)[e.message] ?? t.err_generic); } finally { setBusy(false); }
  }

  return (
    <div>
      <h1 className="serif text-3xl text-rose-light mb-6">{t.a_settings}</h1>

      <GlassCard className="p-5 mb-4">
        <p className="text-cream/70 text-sm mb-4">{t.set_rewards}</p>
        {rules!.map((r, i) => (
          <div key={r.code} className="flex items-center gap-3 mb-2">
            <input type="number" value={r.threshold}
              onChange={(e) => { const v = [...rules!]; v[i] = { ...r, threshold: +e.target.value }; setRules(v); }}
              className="w-16 px-2 py-2 rounded-lg bg-cream/10 border border-cream/15 text-cream text-center outline-none" />
            <input value={lang === "zh" ? r.label_zh : r.label_en}
              onChange={(e) => { const v = [...rules!]; v[i] = { ...r, [lang === "zh" ? "label_zh" : "label_en"]: e.target.value }; setRules(v); }}
              className="flex-1 px-3 py-2 rounded-lg bg-cream/10 border border-cream/15 text-cream outline-none text-sm" />
            {r.resets && <span className="text-gold text-xs">↻ reset</span>}
          </div>
        ))}
      </GlassCard>

      <GlassCard className="p-5 mb-4">
        <p className="text-cream/70 text-sm mb-4">📍 {t.set_market}</p>
        <div className="grid grid-cols-2 gap-2">
          <Inp label={t.set_place} value={market.place} onChange={(v) => setMarket({ ...market, place: v })} full />
          <Inp label={t.set_date} value={market.date} onChange={(v) => setMarket({ ...market, date: v })} />
          <Inp label={t.set_time} value={market.time} onChange={(v) => setMarket({ ...market, time: v })} />
          <Inp label={t.set_note} value={market.note} onChange={(v) => setMarket({ ...market, note: v })} full />
        </div>
      </GlassCard>

      <button onClick={save} disabled={busy}
        className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-rose to-rose-deep text-cocoa-dark font-semibold shadow-gold tap mb-6 active:scale-[0.99]">
        {saved ? `✓ ${t.set_saved}` : t.set_save}
      </button>

      <GlassCard className="p-5">
        <p className="text-cream/70 text-sm mb-3">{t.set_export}</p>
        <div className="flex gap-2">
          <a href="/api/export?format=csv" className="flex-1 py-3 rounded-xl glass text-cream flex items-center justify-center gap-2 text-sm tap">
            <Download size={16} /> {t.set_export_csv}
          </a>
          <a href="/api/export?format=xlsx" className="flex-1 py-3 rounded-xl glass text-cream flex items-center justify-center gap-2 text-sm tap">
            <Download size={16} /> {t.set_export_xlsx}
          </a>
        </div>
      </GlassCard>
    </div>
  );
}

function Inp({ label, value, onChange, full }: { label: string; value: string; onChange: (v: string) => void; full?: boolean }) {
  return (
    <label className={`block ${full ? "col-span-2" : ""}`}>
      <span className="text-cream/50 text-xs mb-1 block">{label}</span>
      <input value={value} onChange={(e) => onChange(e.target.value)}
        className="w-full px-3 py-2.5 rounded-xl bg-cream/10 border border-cream/15 text-cream outline-none focus:border-rose/60 text-sm" />
    </label>
  );
}
