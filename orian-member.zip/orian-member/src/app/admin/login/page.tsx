"use client";
import { motion } from "framer-motion";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useState } from "react";
import { Logo, LangToggle } from "@/components/ui";
import { useLang } from "@/i18n/LangProvider";
import { api } from "@/lib/client";

export default function AdminLogin() {
  const { t } = useLang();
  const router = useRouter();
  const [username, setUsername] = useState("Owner");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit() {
    setErr(""); setBusy(true);
    try {
      await api("/api/auth", { method: "POST", body: JSON.stringify({ username, password }) });
      router.push("/admin/dashboard");
    } catch (e: any) {
      setErr((t as any)[e.message] ?? t.err_login_failed);
    } finally { setBusy(false); }
  }

  return (
    <main className="min-h-screen bg-cocoa-atmos flex flex-col px-6">
      <header className="flex items-center justify-between max-w-md mx-auto w-full py-5">
        <Link href="/"><Logo size={40} /></Link>
        <LangToggle />
      </header>
      <div className="flex-1 flex items-center justify-center">
        <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }}
          className="glass rounded-3xl p-8 w-full max-w-sm shadow-card">
          <h1 className="serif text-4xl text-rose-light text-center mb-6">{t.a_login}</h1>
          <div className="space-y-4">
            <div>
              <span className="text-cream/60 text-xs mb-1.5 block">{t.a_username}</span>
              <select value={username} onChange={(e) => setUsername(e.target.value)} className="inp">
                <option>Owner</option><option>Staff 1</option><option>Staff 2</option>
              </select>
            </div>
            <div>
              <span className="text-cream/60 text-xs mb-1.5 block">{t.a_password}</span>
              <input type="password" inputMode="numeric" value={password}
                onChange={(e) => setPassword(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit()}
                placeholder="••••" className="inp" />
            </div>
            {err && <p className="text-strawberry text-sm text-center">{err}</p>}
            <button onClick={submit} disabled={busy}
              className="w-full py-4 rounded-full bg-gradient-to-r from-rose to-rose-deep text-cocoa-dark font-semibold shadow-gold tap disabled:opacity-50 transition hover:scale-[1.02]">
              {busy ? t.loading : t.a_signin}
            </button>
          </div>
        </motion.div>
      </div>
      <style jsx>{`
        .inp { width: 100%; padding: 0.85rem 1rem; border-radius: 1rem; background: rgba(246,239,233,0.07);
          border: 1px solid rgba(246,239,233,0.15); color: #f6efe9; outline: none; }
        .inp:focus { border-color: rgba(198,162,162,0.6); }
        select.inp option { background: #2a1d1d; }
      `}</style>
    </main>
  );
}
