"use client";
import { motion, AnimatePresence } from "framer-motion";
import { Search, Plus, Gift, Instagram, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { AdminShell } from "@/components/AdminShell";
import { Celebration } from "@/components/Celebration";
import { useLang } from "@/i18n/LangProvider";
import { api, igUrl } from "@/lib/client";
import { TOTAL_STAMPS, unlockedRewards, type Member, type RewardRule } from "@/lib/types";

export default function MarketModePage() {
  return <AdminShell><MarketMode /></AdminShell>;
}

function MarketMode() {
  const { t, lang } = useLang();
  const [q, setQ] = useState("");
  const [results, setResults] = useState<Member[]>([]);
  const [active, setActive] = useState<Member | null>(null);
  const [rules, setRules] = useState<RewardRule[]>([]);
  const [celebrate, setCelebrate] = useState<{ title: string; sub?: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const debounce = useRef<any>(null);

  const search = (term: string) => {
    setQ(term);
    clearTimeout(debounce.current);
    debounce.current = setTimeout(() => {
      api<Member[]>(`/api/members?q=${encodeURIComponent(term)}`).then(setResults).catch(() => {});
    }, 200);
  };

  useEffect(() => {
    api("/api/settings").then((s) => setRules(s.reward_rules ?? [])).catch(() => {});
    api<Member[]>(`/api/members?q=`).then(setResults).catch(() => {});
  }, []);

  async function addStamp(m: Member) {
    if (busy) return; setBusy(true);
    try {
      const res = await api<{ stamps: number; justUnlocked: RewardRule | null }>("/api/stamps", {
        method: "POST", body: JSON.stringify({ member_id: m.id, delta: 1 }),
      });
      const updated = { ...m, stamps: res.stamps };
      setActive(updated);
      setResults((r) => r.map((x) => (x.id === m.id ? updated : x)));
      if (res.justUnlocked) {
        const lbl = lang === "zh" ? res.justUnlocked.label_zh : res.justUnlocked.label_en;
        setCelebrate({ title: lang === "zh" ? "奖励解锁！" : "Reward Unlocked!", sub: lbl });
      } else {
        setCelebrate({ title: `+1 🍓`, sub: `${res.stamps}/${TOTAL_STAMPS}` });
      }
    } catch { /* noop */ } finally { setBusy(false); }
  }

  async function redeem(m: Member, rule: RewardRule) {
    if (busy) return; setBusy(true);
    try {
      const res = await api<{ reset: boolean }>("/api/redemptions", {
        method: "POST", body: JSON.stringify({ member_id: m.id, reward_code: rule.code }),
      });
      const newStamps = res.reset ? 0 : m.stamps;
      const updated = { ...m, stamps: newStamps };
      setActive(updated);
      setResults((r) => r.map((x) => (x.id === m.id ? updated : x)));
      setCelebrate({ title: lang === "zh" ? "已兑换" : "Redeemed", sub: lang === "zh" ? rule.label_zh : rule.label_en });
    } catch (e: any) {
      alert((t as any)[e.message] ?? t.err_generic);
    } finally { setBusy(false); }
  }

  return (
    <div className="min-h-[80vh]">
      <Celebration show={!!celebrate} title={celebrate?.title ?? ""} subtitle={celebrate?.sub} onDone={() => setCelebrate(null)} />
      <h1 className="serif text-3xl text-rose-light mb-1">{t.a_market_mode}</h1>
      <p className="text-cream/50 text-sm mb-5">{t.m_search}</p>

      {/* HUGE search bar */}
      <div className="relative mb-5">
        <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-cream/40" size={26} />
        <input value={q} onChange={(e) => search(e.target.value)} autoFocus
          placeholder={t.m_search} inputMode="tel"
          className="w-full pl-14 pr-5 py-6 rounded-3xl text-2xl bg-cream/10 border border-cream/15 text-cream placeholder-cream/30 outline-none focus:border-rose/60 transition" />
      </div>

      {/* Results grid — big tappable cards */}
      <p className="text-cream/40 text-xs mb-2">{q ? `${results.length} ` : t.m_recent}</p>
      {results.length === 0 && q && (
        <div className="glass rounded-3xl p-8 text-center">
          <p className="text-cream/50 mb-4">{t.m_no_result}</p>
          <a href={`/register`} className="text-gold hover:underline">{t.m_new_member}</a>
        </div>
      )}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {results.map((m) => (
          <button key={m.id} onClick={() => setActive(m)}
            className="glass rounded-2xl p-4 flex items-center gap-3 text-left tap hover:border-rose/40 transition">
            <div className="w-12 h-12 rounded-xl overflow-hidden ring-1 ring-rose/30 bg-cocoa-dark flex items-center justify-center shrink-0">
              {m.avatar_url ? <img src={m.avatar_url} alt="" className="w-full h-full object-cover" /> : <span className="serif text-xl text-rose">{(m.ig_handle ?? "O")[0]?.toUpperCase()}</span>}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-cream font-medium truncate">{m.ig_handle ? `@${m.ig_handle}` : m.phone}</p>
              <p className="text-cream/40 text-xs">{m.phone}</p>
            </div>
            <span className="serif text-2xl text-gold">{m.stamps}<span className="text-cream/30 text-sm">/{TOTAL_STAMPS}</span></span>
          </button>
        ))}
      </div>

      {/* Action sheet for active member */}
      <AnimatePresence>
        {active && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 flex items-end md:items-center justify-center bg-cocoa-dark/70 backdrop-blur-sm p-4"
            onClick={() => setActive(null)}>
            <motion.div initial={{ y: 60, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 60, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="glass-light rounded-3xl p-6 w-full max-w-md shadow-card text-cocoa">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 rounded-2xl overflow-hidden ring-2 ring-rose/40 bg-cocoa flex items-center justify-center">
                    {active.avatar_url ? <img src={active.avatar_url} alt="" className="w-full h-full object-cover" /> : <span className="serif text-2xl text-rose">{(active.ig_handle ?? "O")[0]?.toUpperCase()}</span>}
                  </div>
                  <div>
                    <p className="serif text-xl text-cocoa">{active.ig_handle ? `@${active.ig_handle}` : active.phone}</p>
                    <p className="text-cocoa/50 text-xs">{active.phone}</p>
                  </div>
                </div>
                <button onClick={() => setActive(null)} className="text-cocoa/40"><X size={22} /></button>
              </div>

              <div className="text-center my-4">
                <p className="serif text-5xl text-cocoa">{active.stamps}<span className="text-cocoa/30 text-2xl">/{TOTAL_STAMPS}</span></p>
                <p className="text-cocoa/50 text-xs">{t.m_stamps_now}</p>
              </div>

              <button onClick={() => addStamp(active)} disabled={busy || active.stamps >= TOTAL_STAMPS}
                className="w-full py-5 rounded-2xl bg-gradient-to-r from-rose to-rose-deep text-cocoa-dark font-bold text-xl flex items-center justify-center gap-2 tap shadow-gold disabled:opacity-40 transition active:scale-95 mb-3">
                <Plus size={26} /> {t.m_addstamp}
              </button>

              {/* Redeemable rewards */}
              {unlockedRewards(active.stamps, rules).map((r) => (
                <button key={r.code} onClick={() => redeem(active, r)} disabled={busy}
                  className="w-full py-3 rounded-xl bg-gold/15 border border-gold/40 text-cocoa font-medium flex items-center justify-center gap-2 tap mb-2 transition active:scale-95">
                  <Gift size={18} /> {t.m_redeem}: {lang === "zh" ? r.label_zh : r.label_en}
                </button>
              ))}

              {active.ig_handle && (
                <a href={igUrl(active.ig_handle)} target="_blank" rel="noreferrer"
                  className="w-full py-3 rounded-xl text-cocoa/60 flex items-center justify-center gap-2 text-sm hover:text-cocoa transition">
                  <Instagram size={16} /> @{active.ig_handle}
                </a>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
